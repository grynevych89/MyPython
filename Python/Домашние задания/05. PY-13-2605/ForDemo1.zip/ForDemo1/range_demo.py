diapazon = range(10, -10, -1)
print(diapazon)

for k in diapazon:
    print(k, end=' ')
print('\n')

a = 1
for k in range(3, 0, -1):
    a += 1
    print(f'{k} -> {a}')

print(a)
