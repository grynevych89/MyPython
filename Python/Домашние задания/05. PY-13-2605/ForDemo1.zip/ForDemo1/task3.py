n = int(input('Введите количество символов: '))
for k in range(n):
    print('*', end='')
