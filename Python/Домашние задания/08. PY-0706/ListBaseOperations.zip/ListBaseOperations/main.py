from lib import *


if __name__ == '__main__':

    # append_demo()
    # insert_demo()
    # remove_demo()
    # pop_demo()
    # del_demo()
    # count_demo()
    # sort_demo()
    # reverse_demo()
    slice_demo()
